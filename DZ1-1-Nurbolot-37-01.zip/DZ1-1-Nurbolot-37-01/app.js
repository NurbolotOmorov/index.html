var name = prompt('напишите свою имю')
var surname = prompt('напишите свою фамилию')
if(name. charAt(0) === name.charAt(0).toUpperCase() && surname.charAt(0) === surname.charAt(0).toUpperCase()){
    alert('здраствуйте' +' '+name + ' '+ surname +'!')
}else{
    alert('пишите за гланой буквы')
}

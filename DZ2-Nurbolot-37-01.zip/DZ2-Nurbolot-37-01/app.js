var numbers = [34,65,67,89,8,9,23,21,10,23,28]
for (var i = 0; i < numbers.length; i++){
    if (numbers[i] % 2 === 0){
        console.log(numbers[i])
    }
}





var cinema = {
    films: [
        {
            title: ' жаны кошуна',
            genre: 'комедия',
            premiereData: '2024-03-28',
            duration: '2024-04-10',
            actors: ['Эрмек Талайбеков, Нурсултан Курсанали Уулу, Бегимай Турусбекова, Алтынай Эмильбекова, Кумондор Абылов, Жээнбек Моношев, Гулжамал МамытбековаТемирлан Искендеров, Элнарбек Дайырбеков',],
            ticketPrice: '200сом',
            dimension: '2D/3D'
        },
        //другие фильмы
    ]
}
var newFilms = {
    title: 'кун-фу панда 4',
    genre: 'мултьфильм,комедия',
    premiereData: '2024-03-30',
    duration: '10 дней',
    actors: 'Джек Блэк, Аквафина, Виола Дэвис, Дастин Хоффман, Джеймс Хун, Брайан Крэнстон, Иэн Макшейн, Ке Хюи Куан, Ронни Чиэн, Лори Тань Чинн',
    ticketPrice: '280сом',
    dimension: '2D',
}
cinema.films.push(newFilms)
console.log(cinema)

function drawNumber(nuber){
    switch (number){
        case 1:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 2:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 3:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 4:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 5:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 6:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 7:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 8:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 9:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 10:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 11:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 12:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 13:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 14:
            console.log('###\n# #\n# #\n# #\n###')
            break
        case 15:
            console.log('###\n# #\n# #\n# #\n###')
            break
    }
}



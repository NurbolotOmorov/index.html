var files = [
    'document.txt', 'image.png', 'screenshot.jpeg',
    'document2.txt', 'textfile.txt', 'picture.png'
]
var text = []
for (var i = 0; i < files.length; i++){
    files.includes('txt')
}
console.log(text)


//2
var dollars = [23000, 45000, 67000]
var soms = []

for (var i = 0; i < dollars.length;i++){
   soms.push(dollars[i]/89)
}
console.log(soms)

//3
var courses = {
    javaScript: ['Ruslan', 'Farida', 'Agzam', 'Marlen', 'Aidana'],
    python: ['Esen', 'Emir', 'Ismar', 'Elkhan'],
    java: ['Bektur', 'Aziz', 'Akai', ' Danil', 'Daniel'],
    ios: ['Akai', 'Danil', 'Daniel']
}



//4
var array = [3,4,5]
console.log(4, array)